﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Airbnb_Assignment3
{
    class Country
    {
        ////////////////LIST OF ALL VARIABLES FOR COUNTRY CLASS////////////////////
        private string countryNamn;
        private int countryInvånare;
        private int countryBnpPerCapita;
        private List<City> cityList = new List<City>();


        ////////////////// CONSTRUCTOR /////////////////////////
        public Country(string CountryNamn, int CountryInvånare, int CountryBnpPerCapita)
        {
            countryNamn = CountryNamn;
            countryInvånare = CountryInvånare;
            countryBnpPerCapita = CountryBnpPerCapita;
            cityList = CityList;
        }
        //////////////////GETTERS AND SETTERS FOR ALL THE CONSTRUCTORS ////////////////////////
        public string CountryNamn
        {
            get { return countryNamn; }
            set { countryNamn = value; }
        }
        public int CountryInvånare
        {
            get { return countryInvånare; }
            set { countryInvånare = value; }
        }
        public int CityBnpPerCapita
        {
            get { return countryBnpPerCapita; }
            set { countryBnpPerCapita = value; }
        }
        public List<City> CityList
        {
            get { return cityList; }
            set { cityList = value; }
        }
        public void AddCity(City myCity)
        {
            CityList.Add(myCity);
        }
    }
}
