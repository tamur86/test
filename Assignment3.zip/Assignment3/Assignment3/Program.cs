﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Airbnb_Assignment3
{
    static class Program
    {
        /// <summary>
        /// THIS IS THE MAIN OF THE PROGRAM ////////////////////////////
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Graph());
        }
    }
}
